<div class="container pb-5">

    <h4 class="mt-3">Shopping Cart</h4>
    
        <table class="table">
            <thead>
                <tr>
                    <th>Items</th>
                    <th>Price</th>
                    <th>Qty</th>
                    <th>Total</th>
                    <th>Actions</th>
                </tr>
                
            </thead>
            <tbody id="detail_cart">
                
 
            </tbody>
        </table>
        <div class="text-end">
        <a href=" <?php echo base_url('Checkout') ?> " class="btn btn-primary"> check out </a>
        </div>
       
       

</div>
